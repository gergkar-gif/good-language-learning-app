# Hungarian A1 Unit 1

Built from the uploaded Hungarian A1 authoring template and the agreed 30-lesson blueprint. The sequencing was cross-checked against ELTE beginner-course topics and University of Veterinary Medicine Budapest A1/1, whose first weeks cover basic expressions, the Hungarian alphabet, vowel harmony, pronouns, lenni, and early locative/conjugation material. The unit deliberately slows this sequence into five small lessons: alphabet, subject recognition, verb-person recognition, tense recognition, and basic sentence structure. Lesson texts are original.
