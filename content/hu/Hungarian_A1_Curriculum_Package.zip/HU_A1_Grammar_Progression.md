# Hungarian A1 Grammar Progression

## Design principle

Hungarian A1 should not treat grammar as a list of endings to memorise.

The learner should repeatedly learn to ask:

1.  What is the verb?
2.  What information is encoded in the verb?
3.  What is the noun doing in the sentence?
4.  What ending marks that role?
5.  Why does the ending have this particular form?
6.  What older grammatical system does this new form connect to?

## Micro-grammar sequence

### 1. Hungarian words carry information

Introduce the general idea that Hungarian frequently attaches
grammatical information to words.

Examples should be simple and visual:

-   ház
-   házak
-   házat
-   házban

Do not introduce the complete case system.

### 2. The verb can identify the subject

English: - I work. - You work. - He works.

Hungarian: - dolgozom - dolgozol - dolgozik

Teach learners to look at the verb ending.

### 3. The verb can identify tense

Use a small contrast first.

-   dolgozom
-   dolgoztam

The initial goal is recognition, not mastery of the entire past tense.

### 4. Vowel harmony

Teach the concept before multiplying suffixes.

Core vowel groups: - back: a, á, o, ó, u, ú - front: e, é, i, í, ö, ő,
ü, ű

Explain that many suffixes have two or three forms.

### 5. Accusative

Introduce -t as the direct-object marker.

Keep examples extremely simple.

### 6. -ban/-ben

Meaning: - in - inside

Teach: - function - form choice - vowel harmony

### 7. -on/-en/-ön

Teach this as a separate grammatical lesson.

Do not pretend it is simply another form of -ban/-ben.

Use high-frequency examples such as: - Budapesten - az asztalon

### 8. The Budapest problem

This deserves its own explanation.

The learner sees: - Budapesten - Budapestre - Budapestről

Explain that Hungarian has a location system built around different
spatial relationships.

The goal is not to teach all location cases at once.

### 9. Movement into

-   -ba/-be

Contrast: - a házban = in the house - a házba = into/to the house

### 10. Movement onto/to

-   -ra/-re

Contrast: - az asztalon = on the table - az asztalra = onto the table

### 11. Movement from

Introduce: - -ból/-ből - -ról/-ről

Use controlled spatial contrasts.

### 12. Possession

Teach possession as morphology.

Compare: - ház - házam - házad

Do not introduce every possessive construction immediately.

### 13. Indefinite conjugation

Start with a small set of frequent regular verbs.

### 14. Verb decoding

Teach the learner to segment a form conceptually:

> stem + grammatical information

For example, the learner should be able to ask what part of a form
signals: - person - number - tense - conjugation type

### 15. Definite vs indefinite conjugation

Use concrete objects.

-   Olvasok.
-   Olvasom a könyvet.

The explanation should answer: "Why did the verb change?"

### 16. Definite present

Introduce the common pattern through complete sentences rather than
isolated paradigms.

### 17. Past tense

Begin with recognition and a small number of high-frequency forms.

### 18. Modal + infinitive

Introduce: - kell - lehet - szabad - akar

Use simple sentences.

### 19. Verbal prefixes

Introduce only a small number.

The learner should first understand: - a prefix can modify the meaning
of a verb; - it may interact with sentence structure; - common prefixed
verbs are worth learning as meaningful units.

## Explanation format

Every grammar explanation should follow this structure:

### What does it mean?

One sentence.

### How does it work?

Two to four sentences.

### Why does it look like this?

Only the relevant rule.

### Examples

Three to five examples.

### Notice

One pattern the learner should observe.

### Practice

Start with recognition, then selection, then controlled production.

## Avoid

-   unexplained grammatical terminology;
-   full paradigms before the learner has seen the forms in context;
-   introducing multiple new suffix families in one explanation;
-   saying "just memorise this" when a useful pattern can be explained;
-   giving a technically correct explanation that is too abstract for
    A1.

## Hungarian decoding routine

This should become a recurring exercise type:

> **Find the verb.**
>
> **Who is doing it?**
>
> **When does it happen?**
>
> **Is there a definite object?**
>
> **What endings are attached to the nouns?**
>
> **What does each ending contribute?**

This should eventually become automatic.
