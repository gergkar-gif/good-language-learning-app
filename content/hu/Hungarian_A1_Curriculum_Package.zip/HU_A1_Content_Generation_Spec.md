# Hungarian A1 Content Generation Specification

## Lesson scale

A1 contains 30 lessons.

Each lesson is small and self-contained.

### Required components

-   1 principal grammar target
-   0-1 supporting grammar targets
-   10-15 new vocabulary items
-   10-sentence reading
-   20-30 practice interactions where appropriate
-   review material
-   Workshop drill

## Ten-sentence reading rules

Every A1 lesson has exactly 10 sentences.

### Sentence difficulty

Early A1: - one simple clause; - familiar subjects; - repeated verbs; -
repeated structures.

Middle A1: - occasional conjunctions; - simple time/place expressions; -
controlled variation.

Late A1: - slightly longer sentences; - limited coordination; -
accumulated grammar; - still clearly A1.

### Vocabulary control

A reading should contain mostly: - previously taught vocabulary; -
high-frequency Hungarian; - lesson vocabulary.

Only a small number of words should be genuinely unfamiliar.

### Grammar control

The target grammar should appear repeatedly.

If the lesson teaches -ban/-ben, the reading should contain multiple
examples rather than one token.

## Exercise progression

A new form should normally be practised in this order:

1.  Recognition
2.  Meaning selection
3.  Form selection
4.  Controlled completion
5.  Sentence assembly
6.  Limited production
7.  Later mixed review

## Verb drills

Hungarian verb drills should teach decoding as well as conjugation.

Example drill dimensions:

-   identify person;
-   identify number;
-   identify tense;
-   identify definite/indefinite;
-   choose the correct form;
-   produce the form;
-   identify the stem;
-   match verb form to sentence.

## Case drills

Do not ask learners to memorise a list of case names.

Instead drill the semantic relationships:

-   in
-   into
-   on/at
-   onto
-   from inside
-   from a surface/location

Then attach the Hungarian forms.

## Vocabulary selection

Vocabulary should be selected using: - curriculum relevance; - high
frequency; - usefulness in everyday communication; - compatibility with
current grammar; - ability to recycle across later readings.

Corpus frequency can inform selection but should not determine it
mechanically.

## Reading generation

Readings should be original.

External sources may inform: - topic selection; - factual accuracy; -
vocabulary frequency; - grammatical usage.

Do not reproduce copyrighted textbook readings.

## Source/reference layer

The curriculum may use: - MagyarOK for pedagogical sequencing and
thematic comparison; - ELTE course descriptions for grammar/vocabulary
progression; - University of Veterinary Medicine Budapest course
sequences for additional sequencing validation; - HungarianReference for
grammar explanations and examples; - Hungarian corpora for frequency and
usage analysis; - morphological tools for validation.

The app's lesson text, explanations, exercises and readings should be
authored specifically for the app.

## Quality-control checklist

Before accepting an A1 lesson:

-   Is there only one main new grammatical mechanism?
-   Is the explanation understandable to an English speaker?
-   Does the explanation answer "why?" where necessary?
-   Are examples consistent?
-   Does the reading contain exactly 10 sentences?
-   Is most reading vocabulary already known?
-   Does the target grammar recur several times?
-   Are exercises more extensive than the explanation?
-   Is previous grammar recycled?
-   Has the Hungarian been checked by a reliable grammar/morphology
    source?
-   Has the content been checked for naturalness?
-   Are no copyrighted source passages reproduced?
