# Hungarian Curriculum Source Notes

## Primary curriculum references

### MagyarOK

MagyarOK is a CEFR-oriented Hungarian textbook series running from A1 to
B2+. The publisher describes its approach as model-based and focused on
natural language use.

The A1 reader contains 70 short everyday-life texts with comprehension
and vocabulary activities, audio and video. The A2 reader contains 64
short everyday-life texts with comprehension and vocabulary activities
and audio.

Use: - pedagogical sequencing; - thematic coverage; - reading difficulty
benchmarking.

Do not copy textbook or reader text.

### ELTE

ELTE's General Hungarian Language Courses publish level-specific grammar
and vocabulary topics. These are useful for checking that the app's
A1-A2 progression covers topics actually taught in university Hungarian
courses.

Use: - grammar progression; - level boundary checking; -
vocabulary/topic progression.

### University of Veterinary Medicine Budapest

The university publishes a four-course sequence: A1/1, A1/2, A2/1, A2/2.

The A1/2 course explicitly covers areas including past tense, possessive
endings, time endings, postpositions, family, jobs, comparison, definite
conjugation, plural, verbal prefixes, accusative personal pronouns and
future forms of lenni.

Use: - sequencing cross-check; - topic coverage; - consolidation points.

### HungarianReference

HungarianReference is an English-speaker-oriented Hungarian grammar
reference.

It is particularly useful for: - cases; - vowel harmony; - location
triads; - suffix variants; - verb and word-building explanations.

It should be treated as a reference source, not copied as lesson prose.

## Other linguistic resources

Potential later inputs: - Hungarian Webcorpus for frequency and
authentic usage; - Magyar Ispell for morphology; - HuSpaCy for
linguistic analysis and validation; - Common Voice for speech-related
development; - Wiktionary for lexical reference.

These should be incorporated only after their individual licences and
redistribution implications have been checked for the exact use case.

## Important licensing rule

Publicly accessible material is not automatically free to reproduce.

For the app: - use external resources as references and data sources
where their licences permit; - avoid copying textbook passages; -
preserve required attribution where applicable; - avoid NC-licensed
material as a production dependency if commercial distribution may ever
be possible; - document the provenance and licence of every imported
dataset.

## Current curriculum decision

The app should not attempt to reproduce MagyarOK.

Instead, it should use the convergence of existing curricula as evidence
for sequencing, then build an original 30-lesson A1 course with: -
smaller grammar steps; - 10-sentence readings; - substantially more
practice; - explicit explanations of Hungarian-specific concepts; - a
dedicated Workshop/verb-drilling layer.
