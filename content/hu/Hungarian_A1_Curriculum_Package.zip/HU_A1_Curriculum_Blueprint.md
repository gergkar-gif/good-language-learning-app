# Hungarian A1 Curriculum Blueprint

## Purpose

This document defines the proposed Hungarian A1 curriculum for the app.

The curriculum is based on: - existing Hungarian-as-a-foreign-language
course sequences from ELTE and the University of Veterinary Medicine
Budapest; - the CEFR-oriented MagyarOK A1/A2 progression; -
HungarianReference as a grammar reference; - the design principles
established for this app.

This is a new curriculum structure. It does not reproduce textbook
lessons or copyrighted reading texts.

## Core design principles

1.  A1 contains 30 lessons.
2.  Lessons are deliberately small and slow-paced.
3.  Each lesson introduces one principal grammatical mechanism, with
    only small supporting concepts.
4.  Grammar explanations are explicit and concrete.
5.  The course teaches learners how to decode Hungarian, not merely how
    to memorise forms.
6.  New grammar is recycled repeatedly before additional complexity is
    introduced.
7.  A1 readings contain exactly 10 sentences.
8.  Early readings are extremely controlled, with mostly known
    vocabulary and repeated target structures.
9.  Practice is heavier than explanation.
10. Hungarian-specific concepts are taught explicitly:

-   suffixes carrying grammatical information;
-   vowel harmony;
-   subject information encoded in verbs;
-   definite vs indefinite conjugation;
-   case marking;
-   omitted pronouns;
-   Hungarian word order and information structure;
-   verb prefixes, introduced only when appropriate.

11. The Workshop provides concentrated drilling of recently learned
    grammar.
12. The Library contains original graded readings, not copied textbook
    material.

## Standard lesson structure

Each A1 lesson contains:

-   Lesson introduction
-   One main grammar explanation
-   Optional micro-grammar explanation
-   10-sentence reading
-   10-15 target vocabulary items
-   Controlled recognition exercises
-   Form-selection exercises
-   Sentence-completion exercises
-   Limited production
-   Review of previous grammar
-   Workshop drill
-   Short lesson check

## Reading standard

Every A1 lesson has one 10-sentence reading.

Early A1: - 5-10 words per sentence where practical - one main clause -
very high proportion of known vocabulary - heavy repetition

Middle A1: - 8-14 words per sentence where practical - occasional
coordination - increasing reuse of older grammar

Late A1: - 10-18 words per sentence where practical - some natural
variation - still controlled enough for an A1 learner

The reading should teach through repetition rather than introduce a
large number of unknown words.

## A1 lesson map

### Unit 1: Learning to read Hungarian

**01. Hungarian sounds and the alphabet** - alphabet and pronunciation -
long vs short vowels - basic spelling-to-sound relationships - survival
expressions

**02. Finding the subject** - personal pronouns - basic noun phrases -
singular/plural awareness - English subject expectations vs Hungarian
usage

**03. The verb tells us who** - present-tense verb endings - person and
number - recognising the subject from the verb - simple verbs such as
lakik, dolgozik, tanul

**04. The verb tells us when** - present vs past as a concept -
recognising tense information in the verb - no full past-tense
production yet

**05. Building a basic Hungarian sentence** - basic sentence structure -
statements - yes/no questions - negation with nem - Unit 1 review

### Unit 2: Nouns and the first endings

**06. Plurals** - -k - vowel changes where necessary - singular vs
plural recognition - plural noun phrases

**07. The accusative** - direct objects - -t - why Hungarian marks the
object - basic object sentences

**08. Vowel harmony** - front/back vowels - the idea of suffix
families - why one grammatical ending can have multiple forms

**09. In something: -ban/-ben** - inside/within - choosing -ban or
-ben - vowel harmony applied to a real grammatical function

**10. On/at something: -on/-en/-ön** - the second location pattern -
controlled contrast with -ban/-ben - examples such as
Budapest/Budapesten - Unit 2 review

### Unit 3: Location as a system

**11. Why Budapest is Budapesten** - Hungarian location patterns -
cities and surfaces - Budapest, Hungary and similar high-frequency
examples - explain the pattern rather than requiring blind memorisation

**12. Into/to: -ba/-be** - movement into an enclosed place - contrast: -
-ban/-ben = in - -ba/-be = into/to

**13. Onto/to: -ra/-re** - movement to a surface/location - contrast
with -on/-en/-ön

**14. From: -ból/-ből and -ról/-ről** - movement away - two different
location families - carefully controlled examples

**15. Location review** - where? - where to? - where from? - recognition
and production - consolidation of vowel harmony

### Unit 4: Hungarian verbs

**16. Indefinite present conjugation** - present-tense endings -
1st/2nd/3rd person - singular and plural - high-frequency regular verbs

**17. Reading a Hungarian verb** - stem + grammatical information -
identify person - identify number - identify tense - identify
conjugation type where relevant

**18. Definite vs indefinite** - why Hungarian changes the verb
according to the object - indefinite object vs definite object -
controlled pairs: - olvasok - olvasom

**19. Definite present conjugation** - core definite endings -
high-frequency transitive verbs - sentence-based drilling

**20. Verb review** - subject identification - tense recognition -
definite/indefinite recognition - mixed present-tense practice

### Unit 5: Everyday Hungarian

**21. Possession** - my/your/his-her basic possession - possessive
endings - possession as morphology rather than a separate word

**22. Family and people** - family vocabulary - possessive structures -
personal descriptions - adjectives

**23. Time and routine** - clock time - days - daily routines - common
time expressions

**24. Food and shopping** - food vocabulary - accusative recycling -
definite/indefinite conjugation recycling - simple requests and
purchases

**25. Review and consolidation** - mixed noun endings - possession -
verbs - short controlled dialogue

### Unit 6: Expanding the system

**26. Past tense: first production** - past marker - 1st person singular
first - high-frequency verbs - form recognition before production

**27. Past tense: the basic pattern** - additional persons - regular
past forms - indefinite conjugation - controlled production

**28. Modal expressions** - kell - lehet - szabad - akar - +
infinitive - simple everyday uses

**29. Verb prefixes: first encounter** - what a verbal prefix is -
common prefixes such as meg- and el- - how prefixes affect meaning -
only basic recognition and high-frequency examples

**30. A1 consolidation** - reading a 10-sentence text using accumulated
grammar - verb decoding - cases - vowel harmony - possession -
definite/indefinite conjugation - past tense - basic modal expressions -
A1 readiness check

## What is intentionally postponed

The following should not be overloaded into A1:

-   full Hungarian case inventory
-   full imperative
-   full conditional
-   complex subordinate clauses
-   participles
-   advanced word-order theory
-   advanced verbal-prefix behaviour
-   sophisticated information-structure terminology
-   rare irregular conjugations

These belong in A2/B1 once the learner has a functioning grammatical
foundation.

## Target A1 outcome

By the end of A1, the learner should be able to:

-   decode common Hungarian noun endings;
-   understand the basic purpose of case marking;
-   use the main introductory location endings;
-   recognise vowel-harmony patterns;
-   identify the person and number encoded in common verb forms;
-   recognise present and basic past forms;
-   distinguish definite and indefinite present conjugation in common
    contexts;
-   use basic possession;
-   understand basic Hungarian word order;
-   understand common omitted-subject constructions;
-   handle basic everyday interactions;
-   read very short controlled Hungarian texts without translating every
    word.

The aim is not grammatical completeness. The aim is to give the learner
a reliable mental model of how Hungarian works.
